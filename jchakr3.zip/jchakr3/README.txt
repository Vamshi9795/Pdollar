Vamshi Chakrala
Jchakr3

HOW TO RUN:

1. make -f makefile
2. java pdollar

License 
http://en.wikipedia.org/wiki/BSD_licenses#3-clause_license_.28.22Revised_BSD_License.22.2C_.22New_BSD_License.22.2C_or_.22Modified_BSD_License.22.29